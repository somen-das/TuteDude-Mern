# To-Do List API (Backend)

This is the Express.js backend for the To-Do List Application. It provides a robust RESTful API to manage tasks and connects with MongoDB.

## Features
 Code is logically organized into Models, Controllers, Services, and Routes for maintainability.

## Setup and Installation
1. Ensure MongoDB is running locally (default expectation is `mongodb://somen:somen12345@ac-7omxyzd-shard-00-00.wjwylvj.mongodb.net:27017,ac-7omxyzd-shard-00-01.wjwylvj.mongodb.net:27017,ac-7omxyzd-shard-00-02.wjwylvj.mongodb.net:27017/todo-app?ssl=true&replicaSet=atlas-65b041-shard-0&authSource=admin&appName=Cluster0`) or define it in standard environment variables.
2. Navigate to the backend directory: using 'cd backend'
3. Install local dependencies: 'npm i'
4. Start the server (runs on port 5000): 
    Using nodemon (live reload): 'npm run dev'
5. local mongodb is running: `mongodb://127.0.0.1:27017/todoapp`

## API Endpoints

| Method | Endpoint | Description |
|---|---|---|
| `GET` | `/api/tasks` | Fetch all tasks, also search|
| `POST` | `/api/tasks` | Create a newly added task. title is required |
| `PUT` | `/api/tasks/:id` | Update a task's full details. |
| `PATCH` | `/api/tasks/:id/status`| Specifically toggle the 'complete' property. |
| `DELETE` | `/api/tasks/:id` | Delete a single task. |

## Tech Stack
- Node.js ==>  JavaScript Runtime.
- Express.js ==>  Backend framework and server.
- Mongoose ==> library for MongoDB interaction.
- Cors ==>  Middleware to handle cross-origin requests.
- Dotenv ==>  Environment variable loader.
